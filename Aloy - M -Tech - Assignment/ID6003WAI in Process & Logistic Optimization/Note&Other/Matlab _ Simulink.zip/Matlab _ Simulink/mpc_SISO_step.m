% to develop the SISO MPC controller
clear
den_p1 = conv([5 1],[5 1]);
den_p1 = conv(den_p1, den_p1);
den_p = conv([5 1], den_p1);
den_p_1 = conv([2 1],den_p1);
sys_ex_m = tf(0.8,den_p);
sys_ex_p = tf(1,den_p_1);
Ts = 5;
sys_d_m = c2d(sys_ex_m,Ts);
sys_d_p = c2d(sys_ex_p,Ts);
% No of step response coefficients to represent the process
Ncoeffs = 20;
t = 0:5:Ncoeffs*Ts;

[ym,tim] = step(sys_d_m,t);
[yp,tim] = step(sys_d_p,t);
%plot(tim,y,'*')

% Step response coefficients array
Step_Coeff = [ym(2:20);ym(20)];
Sp = [yp(2:20);yp(20)];

P = 15; % Prediction Horizon 

M = 4; % control horizon

ysp = 1*ones(P,1); % set point at each step into the future

% Control move calculation
% du = (ysp - yfree(J))/ Sj

Nsim = 100;

t_sim = Nsim*Ts; % no of time steps this simulation to run

t_act = 0;

%u_steps = zeros(Nsim,1);
%du_steps = zeros(Nsim-1,1);
time_sim = t_act;
err_k = 0;

% Form the prediction matrices S (P * M)
S = zeros(P,M);
for i = 1:P
    cnt = 1;
    for j = i:-1:max(1,i-M+1)        
        S(i,cnt) = Step_Coeff(j);
        cnt = cnt +1;
    end
end
% Q matrix gives the weight for each output into the prediction horizon
Q = diag(ones(P,1));

% R matrix gives the weight of moves into the prediction horion for each
% inputs
R = 0.5*diag(ones(M,1));


for k = 1:Nsim  % Simulation loop - in real - life its forever
    
    % 1. Compute free response at the Jth step
    % 2. Compute control move
    % 3. Implement first move (here there is only one move)
    
    % 1 . Get free response
    for ii = 1:P
        free_resp = 0;
        for i = ii+1:Ncoeffs-1
            ind = k+ii - i;
            if (ind) > 0
                free_resp = free_resp + Step_Coeff(i)*du_steps(ind);
            else % all prev del u are zero
                break;
            end
        end
        if (k+ii-Ncoeffs) > 0 % Effect of move Ncoeff before.
            free_resp = free_resp + Step_Coeff(Ncoeffs)*u_steps(k+ii-Ncoeffs);
        end
        
        % Adjust for model plant mismatch
        free_resp = free_resp + err_k(k);

        % prediction at y(k+ii)
        ypred(ii) = free_resp;
    end
    % Error E(k+1)
    E_k = ysp - ypred';

    % Control move calculation
    Du_k = inv(S'*Q*S + R)*S'*Q*E_k;

    % Implement the first move
    du = Du_k(1);

    du_steps(k) = du;
    if k-1 > 0
        u_k = u_steps(k-1) + du;
    else
        u_k = du;
    end
    u_steps(k) = u_k;%[u_k;u_steps(1:19)];
    % plant measurement here is one step
    J1 = 1;
    k1 = k + 1;
    ymeas = 0;
    for i = J1+1:Ncoeffs-1
        if (k1+J1 - i) > 0
            ymeas = ymeas + Sp(i)*du_steps(k1+J1-i);
        else % all prev delta u are zero
            break;
        end
    end
    if (k1+J1-Ncoeffs) > 0
        ymeas = ymeas + Sp(Ncoeffs)*u_steps(k1+J1-Ncoeffs);
    end
    yplant(k) = ymeas;
    
    J1 = 1;
    k1 = k + 1;
    ypred_1 = 0;
    for i = J1+1:Ncoeffs-1
        if (k1+J1 - i) > 0
            ypred_1 = ypred_1 + Step_Coeff(i)*du_steps(k1+J1-i);
        else % all prev delta u are zero
            break;
        end
    end
    if (k1+J1-Ncoeffs) > 0
        ypred_1 = ypred_1 + Step_Coeff(Ncoeffs)*u_steps(k1+J1-Ncoeffs);
    end

    err_k(k+1) = ymeas - ypred_1; 
    t_act = t_act + Ts;
    time_sim = [time_sim t_act];
end
figure
subplot(311)
stairs(time_sim,[0 u_steps])
title('u - control moves')
subplot(312)
plot(time_sim,[0 yplant]);  
xlabel('Time in minutes')
title('y - process output')
subplot(313)
plot(time_sim,[err_k]);  
xlabel('Time in minutes')
title('Model plant error')
